package com.qin.editor;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** שמירת וידאו ל-DCIM/QinEditor דרך MediaStore. */
@CapacitorPlugin(name = "QinNative")
public class QinNativePlugin extends Plugin {
    private final Map<String, Object[]> open = new HashMap<>();

    @PluginMethod
    public void begin(PluginCall c) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, c.getString("name"));
            v.put(MediaStore.MediaColumns.MIME_TYPE, c.getString("mime"));
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/QinEditor");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            }
            Uri u = getContext().getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            OutputStream os = getContext().getContentResolver().openOutputStream(u);
            String id = UUID.randomUUID().toString();
            open.put(id, new Object[]{os, u});
            JSObject r = new JSObject();
            r.put("id", id);
            c.resolve(r);
        } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void write(PluginCall c) {
        try {
            ((OutputStream) open.get(c.getString("id"))[0]).write(Base64.decode(c.getString("data"), Base64.DEFAULT));
            c.resolve();
        } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void finish(PluginCall c) {
        try {
            Object[] o = open.remove(c.getString("id"));
            ((OutputStream) o[0]).close();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContext().getContentResolver().update((Uri) o[1], v, null, null);
            }
            c.resolve();
        } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
    }
}
