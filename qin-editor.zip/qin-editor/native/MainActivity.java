package com.qin.editor;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(QinNativePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
