'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],el=(t,h)=>{const e=document.createElement(t);if(h!=null)e.innerHTML=h;return e},btn=(t,f)=>{const b=el('button',t);b.onclick=f;return b};
const F={none:'none',cine:'contrast(1.15) saturate(.85) sepia(.15) hue-rotate(-8deg)',warm:'sepia(.25) saturate(1.2)',cool:'hue-rotate(12deg) saturate(.9)',bw:'grayscale(1) contrast(1.1)',vivid:'saturate(1.5) contrast(1.08)'};
const P={clips:[],texts:[],music:null,ratio:'9:16',filter:'none',fade:.4,fit:0};
let sel=0,ts=-1,tab='clip',T=0,playing=false,t0=0,T0=0,cur=null,exporting=false,cancel=false,rec=null,Q=540;
const cv=$('#cv'),x=cv.getContext('2d'),ac=new(window.AudioContext||webkitAudioContext)(),master=ac.createGain(),mon=ac.createGain(),dest=ac.createMediaStreamDestination();
master.connect(mon);mon.connect(ac.destination);master.connect(dest);
const len=c=>c.m.type=='i'?c.out-c.in:(c.out-c.in)/c.speed,total=()=>P.clips.reduce((a,c)=>a+len(c),0),startOf=i=>P.clips.slice(0,i).reduce((a,c)=>a+len(c),0);
const fmt=s=>(s/60|0)+':'+String(s%60|0).padStart(2,'0');
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),2200)}
function size(){const r={'9:16':[9,16],'1:1':[1,1],'16:9':[16,9]}[P.ratio],k=Q/Math.min(...r);cv.width=Math.round(r[0]*k);cv.height=Math.round(r[1]*k)}
function at(t){let a=0;for(let i=0;i<P.clips.length;i++){const d=len(P.clips[i]);if(t<a+d||i==P.clips.length-1)return[i,Math.max(0,Math.min(d,t-a))];a+=d}return[0,0]}

/* ייבוא */
$('#file').onchange=async e=>{ac.resume();for(const f of e.target.files){try{await addMedia(f)}catch{toast('הקובץ לא נתמך')}}e.target.value='';ui()};
async function addMedia(f){const u=URL.createObjectURL(f),img=f.type.startsWith('image');let e,dur=3;
  if(img){e=new Image();e.src=u;await e.decode()}else{e=el('video');e.src=u;e.playsInline=true;e.preload='auto';await new Promise((r,j)=>{e.onloadedmetadata=r;e.onerror=j});dur=e.duration}
  const m={el:e,type:img?'i':'v',dur,u};if(!img){m.g=ac.createGain();ac.createMediaElementSource(e).connect(m.g);m.g.connect(master)}
  const c={m,in:0,out:dur,speed:1,vol:1,th:''};P.clips.push(c);thumb(c)}
function thumb(c){const m=c.m;if(m.type=='i'){c.th=m.u;return}m.el.onseeked=()=>{m.el.onseeked=null;const t=el('canvas'),s=Math.max(96/m.el.videoWidth,96/m.el.videoHeight);t.width=t.height=96;t.getContext('2d').drawImage(m.el,(96-m.el.videoWidth*s)/2,(96-m.el.videoHeight*s)/2,m.el.videoWidth*s,m.el.videoHeight*s);c.th=t.toDataURL('image/jpeg',.6);tl()};m.el.currentTime=.1}

/* ציור והפעלה */
function loop(now){requestAnimationFrame(loop);
  if(playing){T=T0+(now-t0)/1000;if(T>=total()){T=total();pauseAll();if(exporting)setTimeout(()=>rec&&rec.state!='inactive'&&rec.stop(),400)}}
  draw();$('#seek').max=total()*100;if(document.activeElement!=$('#seek'))$('#seek').value=T*100;$('#tm').textContent=fmt(T)+' / '+fmt(total());$('#play').textContent=playing?'עצור':'הפעל';if(exporting)$('#bp').value=T/(total()||1)}
function switchTo(c,l){if(cur&&cur.m.type=='v'&&cur.m!==c.m)cur.m.el.pause();cur=c;const m=c.m;if(m.type=='v'){m.g.gain.value=c.vol;m.el.playbackRate=c.speed;m.el.currentTime=c.in+l*c.speed;if(playing)m.el.play().catch(()=>{})}}
function draw(){const w=cv.width,h=cv.height;x.globalAlpha=1;x.filter='none';x.fillStyle='#000';x.fillRect(0,0,w,h);if(!P.clips.length)return;
  const[i,l]=at(T),c=P.clips[i],m=c.m;if(c!==cur)switchTo(c,l);
  if(m.type=='v'){const g=c.in+l*c.speed;if(!playing&&Math.abs(m.el.currentTime-g)>.04)m.el.currentTime=g;else if(playing&&m.el.paused)m.el.play().catch(()=>{})}
  const d=len(c),a=P.fade?Math.min(1,l/P.fade,(d-l)/P.fade):1,sw=m.el.videoWidth||m.el.naturalWidth;
  if(sw){const s=Math[P.fit?'min':'max'](w/sw,h/(m.el.videoHeight||m.el.naturalHeight)),dw=sw*s,dh=(m.el.videoHeight||m.el.naturalHeight)*s;x.globalAlpha=Math.max(0,a);x.filter=F[P.filter];x.drawImage(m.el,(w-dw)/2,(h-dh)/2,dw,dh)}
  x.globalAlpha=1;x.filter='none';const k=Math.min(w,h)/540;
  P.texts.forEach(o=>{if(T<o.s||T>o.e||!o.t)return;x.font=`700 ${o.sz*k}px system-ui,sans-serif`;x.textAlign='center';x.lineJoin='round';x.lineWidth=o.sz*k/5;x.strokeStyle='#000';x.strokeText(o.t,w/2,o.y*h);x.fillStyle=o.c;x.fillText(o.t,w/2,o.y*h)})}
function play(){ac.resume();if(!P.clips.length)return;if(T>=total()-.05)T=0;playing=true;T0=T;t0=performance.now();cur=null;if(P.music){const a=P.music.el;a.currentTime=Math.min(T,a.duration||0);a.play().catch(()=>{})}}
function pauseAll(){playing=false;if(cur&&cur.m.type=='v')cur.m.el.pause();if(P.music)P.music.el.pause()}
$('#play').onclick=()=>playing?pauseAll():play();$('#seek').oninput=e=>{pauseAll();T=e.target.value/100;cur=null};

/* ייצוא */
const b64=b=>new Promise(r=>{const f=new FileReader;f.onload=()=>r(f.result.split(',')[1]);f.readAsDataURL(b)});
$('#exp').onclick=()=>{if(!P.clips.length)return toast('הוסף קליפים קודם');pauseAll();ac.resume();Q=1080;size();T=0;cancel=false;
  const st=cv.captureStream(30);dest.stream.getAudioTracks().forEach(t=>st.addTrack(t));mon.gain.value=0;
  const mt=['video/mp4;codecs=avc1','video/webm;codecs=vp9,opus','video/webm'].find(t=>MediaRecorder.isTypeSupported(t)),ch=[];
  rec=new MediaRecorder(st,{mimeType:mt,videoBitsPerSecond:12e6});rec.ondataavailable=e=>e.data.size&&ch.push(e.data);
  rec.onstop=async()=>{exporting=false;Q=540;size();mon.gain.value=1;$('#busy').hidden=true;if(!cancel)await saveOut(new Blob(ch,{type:mt.split(';')[0]}))};
  exporting=true;$('#busy').hidden=false;rec.start(500);play()};
$('#bc').onclick=()=>{cancel=true;pauseAll();rec&&rec.state!='inactive'&&rec.stop()};
async function saveOut(b){const name=`QIN_EDIT_${Date.now()}.${b.type.includes('mp4')?'mp4':'webm'}`,n=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.QinNative;
  if(n)try{const{id}=await n.begin({name,mime:b.type});for(let i=0;i<b.size;i+=1<<20)await n.write({id,data:await b64(b.slice(i,i+(1<<20)))});await n.finish({id});return toast('נשמר בגלריה ✓')}catch{}
  const a=el('a');a.href=URL.createObjectURL(b);a.download=name;a.click();toast('הקובץ הורד')}

/* ממשק */
function rg(n,v,a,b,s,f){const l=el('label',`<span>${n}</span><input type=range min=${a} max=${b} step=${s} value=${v}>`);l.lastChild.oninput=e=>f(+e.target.value);return l}
function sl2(n,v,o,f){const l=el('label',`<span>${n}</span><select>${o.map(([k,t])=>`<option value="${k}"${k==v?' selected':''}>${t}</option>`).join('')}</select>`);l.lastChild.onchange=e=>f(e.target.value);return l}
function tl(){const e=$('#tl');e.innerHTML='';P.clips.forEach((c,i)=>{const b=el('button',`<img src="${c.th}"><span>${len(c).toFixed(1)}s</span>`);b.className='ch'+(i==sel?' on':'');b.onclick=()=>{pauseAll();sel=i;T=startOf(i);cur=null;ui()};e.append(b)});const a=btn('+ הוסף',()=>$('#file').click());a.className='ch add';e.append(a)}
function jump(end){pauseAll();cur=null;T=startOf(sel)+(end?Math.max(0,len(P.clips[sel])-.1):0);tl()}
function mv(d){const j=sel+d;if(j<0||j>=P.clips.length)return;[P.clips[sel],P.clips[j]]=[P.clips[j],P.clips[sel]];sel=j;ui()}
function split(){const[i,l]=at(T),c=P.clips[i];if(!c||l<.3||len(c)-l<.3)return toast('העבר את הסמן לאמצע הקליפ');const k=c.in+l*(c.m.type=='i'?1:c.speed);P.clips.splice(i+1,0,{...c,in:k});c.out=k;sel=i;ui()}
function del(){P.clips.splice(sel,1);sel=Math.max(0,Math.min(sel,P.clips.length-1));T=0;cur=null;ui()}
function panel(){const p=$('#pn');p.innerHTML='';const c=P.clips[sel];
  if(tab=='clip'){if(!c){p.append(el('p','לחץ על "+ הוסף" כדי לבחור סרטונים ותמונות'));return}const m=c.m;
    p.append(rg('התחלה',c.in,0,m.dur,.05,v=>{c.in=Math.min(v,c.out-.2);jump()}),rg('סוף',c.out,0,m.dur,.05,v=>{c.out=Math.max(v,c.in+.2);jump(1)}));
    if(m.type=='v')p.append(rg('עוצמת קול',c.vol,0,2,.05,v=>{c.vol=v;m.g.gain.value=v}),sl2('מהירות',c.speed,[[.5,'×0.5'],[1,'×1'],[2,'×2'],[4,'×4']],v=>{c.speed=+v;ui()}));
    p.append(btn('פצל בסמן',split),btn('שכפל',()=>{P.clips.splice(sel+1,0,{...c});ui()}),btn('הזז קדימה',()=>mv(-1)),btn('הזז אחורה',()=>mv(1)),btn('מחק',del))}
  if(tab=='text'){p.append(btn('הוסף טקסט',()=>{P.texts.push({t:'טקסט',s:T,e:T+3,y:.8,sz:44,c:'#ffffff'});ts=P.texts.length-1;panel()}));
    P.texts.forEach((o,i)=>p.append(btn((i==ts?'● ':'')+(o.t||'...').slice(0,14),()=>{ts=i;panel()})));const o=P.texts[ts];
    if(o){const t=el('input');t.type='text';t.value=o.t;t.oninput=()=>o.t=t.value;const col=el('input');col.type='color';col.value=o.c;col.oninput=()=>o.c=col.value;const mx=Math.max(total(),10);
      p.append(t,rg('מתחיל',o.s,0,mx,.1,v=>o.s=v),rg('נגמר',o.e,0,mx,.1,v=>o.e=v),rg('גובה',o.y,.05,.95,.01,v=>o.y=v),rg('גודל',o.sz,20,120,1,v=>o.sz=v),col,btn('מחק טקסט',()=>{P.texts.splice(ts,1);ts=-1;panel()}))}}
  if(tab=='music'){p.append(btn(P.music?'החלף מוזיקה':'בחר מוזיקה',()=>$('#afile').click()));
    if(P.music)p.append(el('p',P.music.name),rg('עוצמה',P.music.g.gain.value,0,1.5,.05,v=>P.music.g.gain.value=v),btn('הסר מוזיקה',()=>{P.music.el.pause();P.music.g.disconnect();P.music=null;panel()}))}
  if(tab=='look')p.append(sl2('יחס מסך',P.ratio,[['9:16','לאורך 9:16'],['1:1','ריבוע 1:1'],['16:9','לרוחב 16:9']],v=>{P.ratio=v;size()}),sl2('פילטר',P.filter,[['none','ללא'],['cine','קולנועי'],['warm','חם'],['cool','קר'],['bw','שחור לבן'],['vivid','חי']],v=>P.filter=v),
    sl2('מעבר בין קליפים',P.fade,[[0,'חד'],[.4,'דהייה קצרה'],[1,'דהייה ארוכה']],v=>P.fade=+v),sl2('התאמה למסך',P.fit,[[0,'מילוי המסך'],[1,'הצגה מלאה']],v=>P.fit=+v))}
$('#afile').onchange=e=>{const f=e.target.files[0];if(!f)return;if(P.music){P.music.el.pause();P.music.g.disconnect()}const a=new Audio(URL.createObjectURL(f)),g=ac.createGain();ac.createMediaElementSource(a).connect(g);g.connect(master);g.gain.value=.7;P.music={el:a,g,name:f.name};panel();e.target.value=''};
$$('#tabs button').forEach(b=>b.onclick=()=>{tab=b.dataset.t;$$('#tabs button').forEach(z=>z.classList.toggle('on',z==b));panel()});
function ui(){tl();panel()}
size();ui();requestAnimationFrame(loop);
