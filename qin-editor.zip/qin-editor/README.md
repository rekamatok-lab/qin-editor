# Qin Editor
בנייה: `bash setup.sh` ואז `npx cap open android` (או GitHub Actions, ראה הוראות בצ'אט).
הייצוא מתבצע בזמן אמת: סרטון של דקה לוקח דקה. הקובץ נשמר ל-DCIM/QinEditor בגלריה.
