#!/usr/bin/env bash
set -e
npm install
[ -d android ] || npx cap add android
D=android/app/src/main/java/com/qin/editor
mkdir -p "$D" && cp native/*.java "$D/"
npx cap sync android
echo "מוכן. לבניית APK: npx cap open android -> Build > Build APK(s)"
